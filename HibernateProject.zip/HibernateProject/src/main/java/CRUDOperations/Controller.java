package CRUDOperations;

import java.util.Scanner;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class Controller {

	public static void main(String args[]) {
		
		Controller controller = new Controller();
//		//controller.addpatient();
//		//controller.displaypatientbyId();
//		//controller.updatepatient();
//		controller.deletepatient();
//		
//	}
		Scanner sc = new Scanner(System.in);

        System.out.println("Choose an operation:");
        System.out.println("1. Add Patient");
        System.out.println("2. Display Patient by ID");
        System.out.println("3. Update Patient");
        System.out.println("4. Delete Patient");

        int choice = sc.nextInt();
        sc.nextLine(); 

        switch (choice) {
            case 1:
                controller.addpatient();
                break;
            case 2:
                controller.displaypatientbyId();
                break;
            case 3:
                controller.updatepatient();
                break;
            case 4:
                controller.deletepatient();
                break;
            default:
                System.out.println("Invalid choice.");
        }

        sc.close();
    }
	public void addpatient() {
		
		Configuration configuration = new Configuration();
		configuration.configure("hibernate.cfg.xml");
		
		SessionFactory sf = configuration.buildSessionFactory();
		Session session = sf.openSession();
		
		Transaction t = session.beginTransaction();
		
		Patient patient = new Patient();
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Patient ID :");
		
		
		int pid = sc.nextInt();
		patient.setId(pid);
		
		
		System.out.println("Enter Patient Name :");
		String pname = sc.next();
		patient.setName(pname);
		
		System.out.println("Enter Patient age :");
		int page = sc.nextInt();
		patient.setAge(page);
		
		System.out.println("Enter Patient gender :");
		String pgender = sc.next();
		patient.setGender(pgender);
		
		System.out.println("Enter Patient diagnosis :");
		String pdiagnosis = sc.next();
		patient.setDiagnosis(pdiagnosis);
		
		System.out.println("Enter Patient ContactNumber :");
		String pcontactnumber = sc.next();
		patient.setContactnumber(pcontactnumber);
		
		
		
		session.persist(patient);
		t.commit();
		
		System.out.println("Patient Details Added Successfully");
		
		sc.close();
		session.close();
		sf.close();
		
		
		
		
	}
	public void displaypatientbyId() {
		
		Configuration configuration = new Configuration();
		configuration.configure("hibernate.cfg.xml");
		
		SessionFactory sf = configuration.buildSessionFactory();
		Session session = sf.openSession();
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Patient ID: ");
		int pid = sc.nextInt();
		
		Patient patient = session.find(Patient.class,pid);
		
		if(patient!=null) {
			
			
			System.out.println("Patient ID:"+patient.getId());
			System.out.println("Patient NAME:"+patient.getName());
			System.out.println("Patient AGE:"+patient.getAge());
			System.out.println("Patient GENDER:"+patient.getGender());
			System.out.println("Patient DIAGNOSIS:"+patient.getDiagnosis());
			System.out.println("Patient CONTACTNUMBER:"+patient.getContactnumber());
			
			
		}
		else {
			System.out.println("Patient Data Not Found");
		}
		
		sc.close();
		sf.close();
		session.close();
		
		
	}
	public void updatepatient() {
		
		Configuration configuration = new Configuration();
		configuration.configure("hibernate.cfg.xml");
		
		SessionFactory sf = configuration.buildSessionFactory();
		Session session = sf.openSession();
		
		Transaction t = session.beginTransaction();
		
	    Scanner sc = new Scanner(System.in);
		System.out.println("Enter Patient ID :");
		int pid = sc.nextInt();
		
		Patient patient = session.find(Patient.class, pid);
		
		if(patient!=null) {
			
		
		System.out.println("Enter Patient Name:");
		String pname = sc.next();
		System.out.println("Enter Patient Age:");
		int page= sc.nextInt();
		System.out.println("Enter Patient Diagnosis:");
		String pdiagnosis = sc.next();
		
		patient.setName(pname);
		patient.setAge(page);
		patient.setDiagnosis(pdiagnosis);
		
		t.commit();
		System.out.println("Patient Details Updated Successfully");
		
		}
		else {
			System.out.println("Patient Data Not Found");
		}
		sc.close();
		sf.close();
		session.close();
		
		
		
	}
	public void deletepatient() {
		
		Configuration configuration = new Configuration();
		configuration.configure("hibernate.cfg.xml");
		
		SessionFactory sf = configuration.buildSessionFactory();
		Session session = sf.openSession();
		
		Transaction t = session.beginTransaction();
		
	    Scanner sc = new Scanner(System.in);
		System.out.println("Enter Patient ID :");
		int pid = sc.nextInt();
		
		Patient patient = session.find(Patient.class, pid);
		if(patient!=null) {
			session.remove(patient);
			t.commit();
			System.out.println("Patient Data Deleted Successfully");
		}
		else {
			System.out.println("Patient Details Not Found");
		}
		sc.close();
		sf.close();
		session.close();
	}
}
