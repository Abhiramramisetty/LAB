package CRUDOperations;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="patient_table")
public class Patient {
	
	@Id
	@Column(name="pid")
	private int id;
	@Column(name="pname",length = 50,nullable = false)
	private String name;
	@Column(name="page",nullable = false)
	private int age;
	@Column(name = "pgender",length=10,nullable = false)
	private String gender;
	@Column(name="pdiagnosis",length=50,nullable = false)
	private String diagnosis;
	@Column(name = "pcontactnumber",length = 20,nullable = false,unique = true)
	private String contactnumber;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getDiagnosis() {
		return diagnosis;
	}
	public void setDiagnosis(String diagnosis) {
		this.diagnosis = diagnosis;
	}
	public String getContactnumber() {
		return contactnumber;
	}
	public void setContactnumber(String contactnumber) {
		this.contactnumber = contactnumber;
	}
	
	
	
	
	

}
