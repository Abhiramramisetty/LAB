package InheritanceMapping;

import jakarta.persistence.Column;
import jakarta.persistence.DiscriminatorValue;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
@DiscriminatorValue("PASSENGER")
public class Passenger extends Airplane
{
	@Id
	private int id;
	@Column(name="pname",length=50)
	private String name;
	@Column(name="pgender",length=20)
    private String gender;
	@Column(name="pcontact",length = 50,unique=true)
	private String contactnumber;
	@Column(name="pcost")
	private double flightcost;
	@Column(name="pseat",unique=true)
	private int seat;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getContactnumber() {
		return contactnumber;
	}
	public void setContactnumber(String contactnumber) {
		this.contactnumber = contactnumber;
	}
	public double getFlightcost() {
		return flightcost;
	}
	public void setFlightcost(double flightcost) {
		this.flightcost = flightcost;
	}
	public int getSeat() {
		return seat;
	}
	public void setSeat(int seat) {
		this.seat = seat;
	}
	
	
	
	

}
