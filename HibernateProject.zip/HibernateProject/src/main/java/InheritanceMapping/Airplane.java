package InheritanceMapping;

import jakarta.persistence.Column;
import jakarta.persistence.DiscriminatorColumn;
import jakarta.persistence.DiscriminatorType;
import jakarta.persistence.DiscriminatorValue;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Inheritance;
import jakarta.persistence.InheritanceType;

@Entity


//Single Table Strategy

@Inheritance(strategy = InheritanceType.SINGLE_TABLE)
@DiscriminatorColumn(name = "type", discriminatorType = DiscriminatorType.STRING, length = 30)
@DiscriminatorValue(value = "AIRPLANE")

//Table per Class Strategy
//@Inheritance(strategy = InheritanceType.TABLE_PER_CLASS)

//Joined Table Strategy
//@Inheritance(strategy =InheritanceType.JOINED)

public class Airplane 
{
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int id;
	@Column(name="aname",length = 50)
	private String airplanename;
	@Column(name="aplace",length=50)
	private String arrival;
	@Column(name="adestination",length = 50)
	private String destination;
	/*
	 * @Column(name="atime",length=20) private String arrivaltime;
	 * 
	 * @Column(name="adeparture",length = 20) private String departuretime;
	 */
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getAirplanename() {
		return airplanename;
	}
	public void setAirplanename(String airplanename) {
		this.airplanename = airplanename;
	}
	public String getArrival() {
		return arrival;
	}
	public void setArrival(String arrival) {
		this.arrival = arrival;
	}
	public String getDestination() {
		return destination;
	}
	public void setDestination(String destination) {
		this.destination = destination;
	}
	/*
	 * public String getArrivaltime() { return arrivaltime; } public void
	 * setArrivaltime(String arrivaltime) { this.arrivaltime = arrivaltime; } public
	 * String getDeparturetime() { return departuretime; } public void
	 * setDeparturetime(String departuretime) { this.departuretime = departuretime;
	 * }
	 */
	
	
	
}
