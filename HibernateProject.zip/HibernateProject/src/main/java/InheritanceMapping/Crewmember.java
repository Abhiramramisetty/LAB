package InheritanceMapping;

import jakarta.persistence.Column;
import jakarta.persistence.DiscriminatorValue;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
@DiscriminatorValue("CREWMEMBER")
public class Crewmember extends Airplane
{
	@Id
	private int id;
	@Column(name="crewname",length = 50)
	private String name;
	@Column(name="crewslot",length = 50)
	private String slotday;
	@Column(name="crewemail",length=50)
	private String email;
	@Column(name="crewsalary")
	private double salary;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getSlotday() {
		return slotday;
	}
	public void setSlotday(String slotday) {
		this.slotday = slotday;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	

}
