package InheritanceMapping;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class InheritanceDemo 
{
	public static void main(String args[])
	  {
		  Configuration cfg = new Configuration();
	  	  cfg.configure("hibernate.cfg.xml");
	  	
	  	  SessionFactory sf = cfg.buildSessionFactory();
	  	  Session session = sf.openSession();
	  	
	  	  Transaction t = session.beginTransaction();
	  	  
	  	  Airplane a = new Airplane();
	  	  
	  	  
	  	  //a.setId(1);
	  	  a.setAirplanename("AirIndia");
	  	  a.setArrival("Hyderabad");
	  	  a.setDestination("Chennai");
			/*
			 * a.setArrivaltime("11:30"); a.setDeparturetime("15:00");
			 */

	  	 
	  	  
	  	 Crewmember c = new Crewmember();
	  	 
	  	 //c.setId(11);
	  	 c.setName("MNO");
	  	 c.setSlotday("Sunday");
	  	 c.setEmail("DEF@gmail.com");
	  	 c.setSalary(150000.00);

	  	  //session.persist(c);
	  	  
	  	  Passenger p = new Passenger();
	  	  
	  	  //p.setId(111);
	  	  p.setName("XYZ");
	  	  p.setGender("Male");
	  	  p.setContactnumber("8963621045");
	  	  p.setFlightcost(4500.64);
	  	  p.setSeat(21);
	  	  
	  	  session.persist(a);
	  	  session.persist(c);
	  	  session.persist(p);
	  	 
	  	   t.commit();
	  	   System.out.println("SUCCESS....");
	  	
	  	session.close();
	  	sf.close();
	  }
	}



